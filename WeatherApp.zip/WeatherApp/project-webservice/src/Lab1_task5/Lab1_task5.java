package Lab1_task5;
import ReadTextFile;

public class Lab1_task5 {
public static void main(String[] args) {
	
	ReadTextFile file = new ReadTextFile();
	file.openFile();
	//file.readFile();
	file.printdifferences();
	file.closeFile();
	
		
	}


}
