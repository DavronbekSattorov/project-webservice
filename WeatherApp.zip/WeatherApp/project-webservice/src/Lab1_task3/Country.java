package Lab1_task3;

public class Country {
	
	private String country;

	public Country(String country) {
		
		this.country = country;
	}

	
	public String toString() {
		return country;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	

}
