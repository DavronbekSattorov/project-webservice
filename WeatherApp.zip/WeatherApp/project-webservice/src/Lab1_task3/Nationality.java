package Lab1_task3;

public class Nationality {
	
	private String nationality;
	
	public Nationality(String nationality) {
		this.nationality = nationality;
		
	}
	
	
	

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	
	public String toString() {
		
		return nationality;
	}
	
	

}
