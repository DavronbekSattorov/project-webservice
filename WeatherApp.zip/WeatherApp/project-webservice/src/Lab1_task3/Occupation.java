package Lab1_task3;

public class Occupation {
	
	private String occupation;
	
	public Occupation(String occupation) {
		this.occupation = occupation;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	
	public String toString() {
		return occupation;
	}
	
	
	
	
	

}
