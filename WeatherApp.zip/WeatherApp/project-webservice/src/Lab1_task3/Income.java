package Lab1_task3;

public class Income {
	
	private double income;
	
	public Income(double income) {
		this.income = income;
		
	}
	
	

	public double getIncome() {
		return income;
	}

	public void setIncome(int income) {
		this.income = income;
	}
	
	public String toString() {
		return income + "zl";
		
	}
	
	

}
