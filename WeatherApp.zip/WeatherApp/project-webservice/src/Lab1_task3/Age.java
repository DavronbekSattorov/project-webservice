package Lab1_task3;

public class Age {

	private int age;
	
	public Age(int age) {
		this.age = age;
		
	}
	
	

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	public String toString() {
		return age + "";
	}
	
	
	
	
	
}
