package Lab2Task1;

class Course {
	
	String description="Course is Computer Science"; 
	// display method of superclass 

	public void displayCourse() { 
	System.out.println("The description from parent class....\n main "+description ); 
	
	}

}
