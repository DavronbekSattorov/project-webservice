package gov.weather.graphical;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet
 */
@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String country = request.getParameter("country");
	   	 
	   	 System.out.println("the Country is:"+country);

	   	 request.getSession().setAttribute("country",country);
//	   	 
//	   	 GlobalWeatherSoapProxy gw = new GlobalWeatherSoapProxy();
//	   	 
//	   	 String output = gw.getCitiesByCountry(country);
	   	 
	   	 response.sendRedirect("city.jsp");
	}

}
